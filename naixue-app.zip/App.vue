<script>
export default {
	onLaunch: function() {
		console.log('App Launch');
	},
	onShow: function() {
		console.log('App Show');
	},
	onHide: function() {
		console.log('App Hide');
	}
};
</script>

<style lang="scss">
/* 每个页面公共css */
@import '@/static/style/app.scss';
/* 引入iconfont */
@import '@/static/iconfont/iconfont.css';
@import '/common/free.css';
@import '/common/common.css';
@import '/common/animate.css';
</style>
