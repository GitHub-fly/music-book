文档已移至[unipay](https://uniapp.dcloud.io/uniCloud/unipay)
